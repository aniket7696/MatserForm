﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace WebApp_Data_binding_with_ado.net_
{
    public partial class WebForm : System.Web.UI.Page
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack)
                PopulateStudent();

        }

        public void PopulateStudent()
        {
            cmd = new SqlCommand("Select * from Student_master", cn);
            cn.Open();
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            if (dr.HasRows)
                dt.Load(dr);
            cn.Close();

            gvStudent.DataSource = dt;
            gvStudent.DataBind();

        }

        public void Insert()
        {
            cmd = new SqlCommand("Insert into Student_master values(@Stud_Code,@Stud_Name,@Dept_Code,@Stud_Dob,@Address)", cn);
            cmd.Parameters.AddWithValue("@Stud_Code", Convert.ToInt32(code.Text));
            cmd.Parameters.AddWithValue("@Stud_Name",txtname.Text);
            cmd.Parameters.AddWithValue("@Dept_Code", Convert.ToInt32(txtdept.Text));
            cmd.Parameters.AddWithValue("@Stud_dob",Convert.ToDateTime( txtdob.Text));
            cmd.Parameters.AddWithValue("@Address",txtAdd.Text);
            cn.Open();
            int recAffected = cmd.ExecuteNonQuery();
            cn.Close();
           
            if(recAffected>0)
            {
                Response.Write("<script type='text/javascript'>alert('Student Record Inserted Successfully')</script>");
                PopulateStudent();

            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('Student Record Not Inserted Successfully')</script>");
            } 
        }

        public void update()
        {
            cmd = new SqlCommand("Update Student_master set Stud_Code=@Stud_Code, Stud_Name=@Stud_Name, Dept_Code=@Dept_Code, Stud_Dob=@Stud_Dob, Address=@Address)", cn);
            cmd.Parameters.AddWithValue("@Stud_Code", Convert.ToInt32(code.Text));
            cmd.Parameters.AddWithValue("@Stud_Name", txtname.Text);
            cmd.Parameters.AddWithValue("@Dept_Code", Convert.ToInt32(txtdept.Text));
            cmd.Parameters.AddWithValue("@Stud_dob", Convert.ToDateTime(txtdob.Text));
            cmd.Parameters.AddWithValue("@Address", txtAdd.Text);
            cn.Open();
            int recAffected = cmd.ExecuteNonQuery();
            cn.Close();
            if (recAffected > 0)
            {
                Response.Write("<script type='text/javascript'>alert('Student Record Updated Successfully')</script>");
                PopulateStudent();

            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('Student Record Not Updated Successfully')</script>");
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            Insert();
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            update();
        }
    }
}